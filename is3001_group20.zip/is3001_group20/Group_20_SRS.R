install.packages("readxl")
library(readxl)
#import the dataset
dataset_1=read_xlsx("C:\\Users\\DELL\\Desktop\\project\\test.xlsx")
attach(dataset_1)

#create a data frame
data1=data.frame(dataset_1) 
attach(data1)
#Identifying missing values in the dataset 
!is.na(data1) 
sum(!is.na(age)) 
sum(!is.na(workclass)) 
sum(!is.na(fnlwgt)) 
sum(!is.na(education)) 
sum(!is.na(education.num)) 
sum(!is.na(marital.status)) 
sum(!is.na(occupation)) 
sum(!is.na(relationship)) 
sum(!is.na(race)) 
sum(!is.na(sex))
sum(!is.na(capital.gain))
sum(!is.na(capital.loss))
sum(!is.na(hours.per.week))
sum(!is.na(native.country))
sum(!is.na(income))
#check factor object 
is.factor(data1)
#Define the factor variables
data1$workclass= as.factor(data1$workclass)
data1$education= as.factor(data1$education)
data1$marital.status= as.factor(data1$marital.status)
data1$occupation= as.factor(data1$occupation)
data1$relationship= as.factor(data1$relationship)
data1$race= as.factor(data1$race)
data1$sex= as.factor(data1$sex)
data1$native.country= as.factor(data1$native.country)
str(data1) 
summary(data1) 

# Question 1: Decide our sample size

install.packages("sampler") 
library(sampler) 

#dependent variable= hours per week
variance=var(data1$age)

n0 = ((1.96^2)*variance)/(3^2) 

n = n0/(1 + n0/ length(data1$age)) 
n = ceiling(n)
print(n)

set.seed(15060) 
sample1_SRS= rsamp(data1, n, rep=FALSE) 
View(sample1_SRS) 

#Question 2: Estimate mean, proportion, total, and their standard errors under different designs. 
install.packages("survey")
library(survey)
#Define survey design
sample1_SRS_design= svydesign(data = sample1_SRS, weights =sample1_SRS$weight, ids = ~1) 
summary(sample1_SRS_design)

#Estimating the mean of age
sample1_age_mean = svymean(~age,sample1_SRS_design)
print(sample1_age_mean)
#Estimating the  total of age
sample1_age_total = svytotal(~age,sample1_SRS_design)
print(sample1_age_total)

#Estimating the mean of fnlwgt
sample1_fnlwgt_mean = svymean(~fnlwgt,sample1_SRS_design)
print(sample1_fnlwgt_mean)
#Estimating the  total of fnlwgt
sample1_fnlwgt_total = svytotal(~fnlwgt,sample1_SRS_design)
print(sample1_fnlwgt_total)

#Estimating the mean of capital_gain
sample1_capital_gain_mean = svymean(~`capital.gain`,sample1_SRS_design)
print(sample1_capital_gain_mean)
#Estimating the  total of capital_gain
sample1_capital_gain_total = svytotal(~`capital.gain`,sample1_SRS_design)
print(sample1_capital_gain_total)


#Estimating the mean of capital_loss
sample1_capital_loss_mean = svymean(~`capital.loss`,sample1_SRS_design)
print(sample1_capital_loss_mean)
#Estimating the  total of capital_loss
sample1_capital_loss_total = svytotal(~`capital.loss`,sample1_SRS_design)
print(sample1_capital_loss_total)
#Estimating the mean of hours_per_week
sample1_hours_per_week_mean = svymean(~`hours.per.week`,sample1_SRS_design)
print(sample1_hours_per_week_mean)
#Estimating the  total of hours_per_week
sample1_hours_per_week_total = svytotal(~`hours.per.week`,sample1_SRS_design)
print(sample1_hours_per_week_total)


#Estimating the propotion of workclass
sample1_workclass_propotion = svymean(~`workclass`,sample1_SRS_design)
print(sample1_workclass_propotion)
#Estimating the  population count of workclass
sample1_workclass_population_count = svytotal(~`workclass`,sample1_SRS_design)
print(sample1_workclass_population_count)

#Estimating the propotion of education
sample1_education_propotion = svymean(~`education`,sample1_SRS_design)
print(sample1_education_propotion)
#Estimating the population count of education
sample1_education_population_count = svytotal(~`education`,sample1_SRS_design)
print(sample1_education_population_count)


#Estimating the propotion of education-num
sample1_education_num_propotion = svymean(~`education.num`,sample1_SRS_design)
print(sample1_education_propotion)
#Estimating the population count of education-num
sample1_education_num_population_count = svytotal(~`education.num`,sample1_SRS_design)
print(sample1_education_num_population_count)

#Estimating the propotion of marital status
sample1_marital_status_propotion = svymean(~`marital.status`,sample1_SRS_design)
print(sample1_marital_status_propotion)
#Estimating the population count of marital status
sample1_marital_status_population_count = svytotal(~`marital.status`,sample1_SRS_design)
print(sample1_marital_status_population_count)

#Estimating the propotion of occupation
sample1_occupation_propotion = svymean(~`occupation`,sample1_SRS_design)
print(sample1_occupation_propotion)
#Estimating the population count of occupation
sample1_occupation_population_count = svytotal(~`occupation`,sample1_SRS_design)
print(sample1_occupation_population_count)

#Estimating the propotion of relationship
sample1_relationship_propotion = svymean(~`relationship`,sample1_SRS_design)
print(sample1_relationship_propotion)
#Estimating the population count of relationship
sample1_relationship_population_count = svytotal(~`relationship`,sample1_SRS_design)
print(sample1_relationship_population_count)

#Estimating the propotion of race
sample1_race_propotion = svymean(~`race`,sample1_SRS_design)
print(sample1_race_propotion)
#Estimating the population count of race
sample1_race_population_count = svytotal(~`race`,sample1_SRS_design)
print(sample1_race_population_count)


#Estimating the propotion of sex
sample1_sex_propotion = svymean(~`sex`,sample1_SRS_design)
print(sample1_sex_propotion)
#Estimating the population count of sex
sample1_sex_population_count = svytotal(~`sex`,sample1_SRS_design)
print(sample1_sex_population_count)



#Estimating the propotion of native country
sample1_native_country_propotion = svymean(~`native.country`,sample1_SRS_design)
print(sample1_native_country_propotion)
#Estimating the population count of native country
sample1_native_country_population_count = svytotal(~`native.country`,sample1_SRS_design)
print(sample1_native_country_population_count)

#Estimating the propotion of income
sample1_income_propotion = svymean(~`income`,sample1_SRS_design)
print(sample1_income_propotion)
#Estimating the population count of income
sample1_income_population_count = svytotal(~`income`,sample1_SRS_design)
print(sample1_income_population_count)


# Question 3: Compare estimates with the actual values from the population 

mean(data1$age)
sqrt(var(data1$age))


mean(data1$fnlwgt)
sqrt(var(data1$fnlwgt))

mean(data1$capital.gain)
sqrt(var(data1$capital.gain))


mean(data1$capital.loss)
sqrt(var(data1$capital.loss))

mean(data1$hours.per.week)
sqrt(var(data1$hours.per.week))



#population propotions

population_workclass_proportion = data.frame(table(data1$workclass)/length(data1$workclass))
print(population_workclass_proportion)

population_education_proportion = data.frame(table(data1$education)/length(data1$education))
print(population_education_proportion)

population_education_num_proportion = data.frame(table(data1$education.num)/length(data1$education.num))
print(population_education_num_proportion)

population_marital_status_proportion = data.frame(table(data1$marital.status)/length(data1$marital.status))
print(population_marital_status_proportion)

population_occupation_proportion = data.frame(table(data1$occupation)/length(data1$occupation))
print(population_occupation_proportion)

population_relationship_proportion = data.frame(table(data1$relationship)/length(data1$relationship))
print(population_relationship_proportion)


population_race_proportion = data.frame(table(data1$race)/length(data1$race))
print(population_race_proportion)


population_sex_proportion = data.frame(table(data1$sex)/length(data1$sex))
print(population_sex_proportion)


population_native_country_proportion = data.frame(table(data1$native.country)/length(data1$native.country))
print(population_native_country_proportion)

population_income_proportion = data.frame(table(data1$income)/length(data1$income))
print(population_income_proportion)


#comparission

comp1_SRS= data.frame(Statistic=c("age_mean", "age_total"),SRS=c(sample1_age_mean,sample1_age_total),Population= c(population_age_mean, population_age_total)) 
print(comp1_SRS)

comp2_SRS= data.frame(Statistic=c("fnlwgt_mean", "fnlwgt_total"),SRS=c(sample1_fnlwgt_mean,sample1_fnlwgt_total),Population= c(population_fnlwgt_mean, population_fnlwgt_total)) 
print(comp2_SRS)

comp3_SRS= data.frame(Statistic=c("capital_gain_mean", "capital_gain_total"),SRS=c(sample1_capital_gain_mean,sample1_capital_gain_total),Population= c(population_capital_gain_mean, population_capital_gain_total)) 
print(comp3_SRS)

comp4_SRS= data.frame(Statistic=c("capital_loss_mean", "capital_loss_total"),SRS=c(sample1_capital_loss_mean,sample1_capital_loss_total),Population= c(population_capital_loss_mean, population_capital_loss_total)) 
print(comp4_SRS)

comp5_SRS= data.frame(Statistic=c("hours_per_week_mean", "hours_per_week_total"),SRS=c(sample1_hours_per_week_mean,sample1_hours_per_week_total),Population= c(population_hours_per_week_mean, population_hours_per_week_total)) 
print(comp5_SRS)


# Question 4: Perform ratio or regression estimations
#fnlwgt 
r1 = svyratio(~sample1_SRS$fnlwgt, ~sample1_SRS$age, sample1_SRS_design) 
r1 
predict(r1, total = population_fnlwgt_total) 

#capital_gain 
r2 = svyratio(~sample1_SRS$capital.gain ,~sample1_SRS$age, sample1_SRS_design) 
r2 
predict(r2, total = population_capital_gain_total) 

#capital_loss 
r3 = svyratio(~sample1_SRS$capital.loss ,~sample1_SRS$age, sample1_SRS_design) 
r3 
predict(r3, total = population_capital_loss_total) 


#hours_per_week 
r4 = svyratio(~sample1_SRS$hours.per.week ,~sample1_SRS$age, sample1_SRS_design) 
r4 
predict(r4, total = population_hours_per_week_total) 

# Question 5: Obtain another sample 


set.seed(2030) 
sample2_SRS= rsamp(data1, n, rep=FALSE) 
View(sample2_SRS) 

# Estimate mean, proportion, total, and their standard errors under different designs. 
install.packages("survey")
library(survey)
#Define survey design
sample2_SRS_design= svydesign(data = sample2_SRS, weights =sample2_SRS$weight, ids = ~1) 
summary(sample2_SRS_design)

#Estimating the mean of age
sample2_age_mean = svymean(~age,sample2_SRS_design)
print(sample2_age_mean)
#Estimating the  total of age
sample2_age_total = svytotal(~age,sample2_SRS_design)
print(sample1_age_total)

#Estimating the mean of fnlwgt
sample2_fnlwgt_mean = svymean(~fnlwgt,sample2_SRS_design)
print(sample2_fnlwgt_mean)
#Estimating the  total of fnlwgt
sample2_fnlwgt_total = svytotal(~fnlwgt,sample2_SRS_design)
print(sample2_fnlwgt_total)

#Estimating the mean of capital_gain
sample2_capital_gain_mean = svymean(~`capital.gain`,sample2_SRS_design)
print(sample2_capital_gain_mean)
#Estimating the  total of capital_gain
sample2_capital_gain_total = svytotal(~`capital.gain`,sample2_SRS_design)
print(sample2_capital_gain_total)


#Estimating the mean of capital_loss
sample2_capital_loss_mean = svymean(~`capital.loss`,sample2_SRS_design)
print(sample2_capital_loss_mean)
#Estimating the  total of capital_loss
sample2_capital_loss_total = svytotal(~`capital.gain`,sample2_SRS_design)
print(sample2_capital_loss_total)

#Estimating the mean of hours_per_week
sample2_hours_per_week_mean = svymean(~`hours.per.week`,sample2_SRS_design)
print(sample2_hours_per_week_mean)
#Estimating the  total of hours_per_week
sample2_hours_per_week_total = svytotal(~`hours.per.week`,sample2_SRS_design)
print(sample2_hours_per_week_total)


#Estimating the propotion of workclass
sample2_workclass_propotion = svymean(~`workclass`,sample2_SRS_design)
print(sample2_workclass_propotion)
#Estimating the  population count of workclass
sample2_workclass_population_count = svytotal(~`workclass`,sample2_SRS_design)
print(sample2_workclass_population_count)

#Estimating the propotion of education
sample2_education_propotion = svymean(~`education`,sample2_SRS_design)
print(sample2_education_propotion)
#Estimating the population count of education
sample2_education_population_count = svytotal(~`education`,sample2_SRS_design)
print(sample2_education_population_count)

#Estimating the propotion of education_num
sample2_education_num_propotion = svymean(~`education.num`,sample2_SRS_design)
print(sample2_education_num_propotion)
#Estimating the population count of education
sample2_education_num_population_count = svytotal(~`education.num`,sample2_SRS_design)
print(sample2_education_num_population_count)

#Estimating the propotion of income
sample2_income_propotion = svymean(~`income`,sample2_SRS_design)
print(sample2_income_propotion)
#Estimating the population count of income
sample2_income_population_count = svytotal(~`income`,sample2_SRS_design)
print(sample2_income_population_count)

#Estimating the propotion of marital status
sample2_marital_status_propotion = svymean(~`marital.status`,sample2_SRS_design)
print(sample1_marital_status_propotion)
#Estimating the population count of marital status
sample2_marital_status_population_count = svytotal(~`marital.status`,sample2_SRS_design)
print(sample2_marital_status_population_count)

#Estimating the propotion of occupation
sample2_occupation_propotion = svymean(~`occupation`,sample2_SRS_design)
print(sample2_occupation_propotion)
#Estimating the population count of occupation
sample2_occupation_population_count = svytotal(~`occupation`,sample2_SRS_design)
print(sample2_occupation_population_count)

#Estimating the propotion of relationship
sample2_relationship_propotion = svymean(~`relationship`,sample2_SRS_design)
print(sample2_relationship_propotion)
#Estimating the population count of relationship
sample2_relationship_population_count = svytotal(~`relationship`,sample2_SRS_design)
print(sample2_relationship_population_count)

#Estimating the propotion of race
sample2_race_propotion = svymean(~`race`,sample2_SRS_design)
print(sample2_race_propotion)
#Estimating the population count of race
sample2_race_population_count = svytotal(~`race`,sample2_SRS_design)
print(sample2_race_population_count)


#Estimating the propotion of sex
sample2_sex_propotion = svymean(~`sex`,sample2_SRS_design)
print(sample2_sex_propotion)
#Estimating the population count of sex
sample2_sex_population_count = svytotal(~`sex`,sample2_SRS_design)
print(sample2_sex_population_count)



#Estimating the propotion of native country
sample2_native_country_propotion = svymean(~`native.country`,sample2_SRS_design)
print(sample2_native_country_propotion)
#Estimating the population count of native country
sample2_native_country_population_count = svytotal(~`native.country`,sample2_SRS_design)
print(sample2_native_country_population_count)


#  Compare estimates with the actual values from the population 

population_age_mean = mean(data1$age)
print(population_age_mean )
population_age_total = sum(data1$age)
print(population_age_total )

population_fnlwgt_mean = mean(data1$fnlwgt)
print(population_fnlwgt_mean )
population_fnlwgt_total = sum(data1$fnlwgt)
print(population_fnlwgt_total) 

population_capital_gain_mean = mean(data1$capital.gain)
print(population_capital_gain_mean )
population_capital_gain_total = sum(data1$capital.gain)
print(population_capital_gain_total) 

population_capital_loss_mean = mean(data1$capital.loss)
print(population_capital_loss_mean )
population_capital_loss_total = sum(data1$capital.loss)
print(population_capital_loss_total)


population_hours_per_week_mean = mean(data1$hours.per.week)
print(population_hours_per_week_mean )
population_hours_per_week_total = sum(data1$hours.per.week)
print(population_hours_per_week_total) 


population_workclass_proportion = data.frame(table(data1$workclass)/length(data1$workclass))
print(population_workclass_proportion)

population_education_proportion = data.frame(table(data1$education)/length(data1$education))
print(population_education_proportion)

population_marital_status_proportion = data.frame(table(data1$marital.status)/length(data1$marital.status))
print(population_marital_status_proportion)

population_occupation_proportion = data.frame(table(data1$occupation)/length(data1$occupation))
print(population_occupation_proportion)

population_relationship_proportion = data.frame(table(data1$relationship)/length(data1$relationship))
print(population_relationship_proportion)


population_race_proportion = data.frame(table(data1$race)/length(data1$race))
print(population_race_proportion)


population_sex_proportion = data.frame(table(data1$sex)/length(data1$sex))
print(population_sex_proportion)


population_native_country_proportion = data.frame(table(data1$native.country)/length(data1$native.country))
print(population_native_country_proportion)


#comparission
comp6_SRS= data.frame(Statistic=c("age_mean", "age_total"),SRS=c(sample2_age_mean,sample2_age_total),Population= c(population_age_mean, population_age_total)) 
print(comp6_SRS)

comp7_SRS= data.frame(Statistic=c("fnlwgt_mean", "fnlwgt_total"),SRS=c(sample2_fnlwgt_mean,sample2_fnlwgt_total),Population= c(population_fnlwgt_mean, population_fnlwgt_total)) 
print(comp7_SRS)

comp8_SRS= data.frame(Statistic=c("capital_gain_mean", "capital_gain_total"),SRS=c(sample2_capital_gain_mean,sample2_capital_gain_total),Population= c(population_capital_gain_mean, population_capital_gain_total)) 
print(comp8_SRS)

comp9_SRS= data.frame(Statistic=c("capital_loss_mean", "capital_loss_total"),SRS=c(sample2_capital_loss_mean,sample2_capital_loss_total),Population= c(population_capital_loss_mean, population_capital_loss_total)) 
print(comp9_SRS)

comp10_SRS= data.frame(Statistic=c("hours_per_week_mean", "hours_per_week_total"),SRS=c(sample2_hours_per_week_mean,sample2_hours_per_week_total),Population= c(population_hours_per_week_mean, population_hours_per_week_total)) 
print(comp10_SRS)

#comparison
#fnlwgt 
r6 = svyratio(~sample2_SRS$fnlwgt, ~sample2_SRS$age, sample2_SRS_design) 
r6 
predict(r6, total = population_fnlwgt_total) 

#capital_gain 
r7 = svyratio(~sample2_SRS$capital.gain ,~sample2_SRS$age, sample2_SRS_design) 
r7 
predict(r7, total = population_capital_gain_total) 

#capital_loss 
r8 = svyratio(~sample2_SRS$capital.loss ,~sample2_SRS$age, sample2_SRS_design) 
r8 
predict(r8, total = population_capital_loss_total) 


#hours_per_week 
r9 = svyratio(~sample2_SRS$hours.per.week ,~sample2_SRS$age, sample2_SRS_design) 
r9 
predict(r9, total = population_hours_per_week_total) 



#Question 6:graphical analysis


svyhist(~age, sample1_SRS_design, main=" Sample1 Histogram of Age",col="blue",probability = FALSE)
svyhist(~fnlwgt, sample1_SRS_design, main=" Sample1 Histogram of fnlwgt", col="red",probability = FALSE) 
svyboxplot(~hours.per.week~sex, sample1_SRS_design, main="Sample1 Boxplot of hours per week with Sex ", col="green" )
svyplot(`fnlwgt`~`age`,design = sample1_SRS_design,style = "bubble",main="Sample1 Plot of fnlwgt vs Age",xlab="Age",ylab="fnlwgt") 


svyhist(~age, sample2_SRS_design, main="Sample2 Histogram of Age", col="blue",probability = FALSE) 
svyhist(~fnlwgt, sample2_SRS_design, main="Sample2 Histogram of fnlwgt",col="red",probability = FALSE) 
svyboxplot(~hours.per.week~sex, sample2_SRS_design, main="Sample2 Boxplot of hours per week with Sex ", col="green" ) 
svyplot(`fnlwgt`~`age`,design= sample2_SRS_design,style = "bubble",main="Sample2 Plot of fnlwgt vs Age",xlab="Age",ylab="fnlwgt") 




