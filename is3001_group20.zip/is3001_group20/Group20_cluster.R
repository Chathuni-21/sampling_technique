library(survey)
library(dplyr)
library(sampler)
library(ggplot2)
setwd("G:/is3001")
dataset= read.csv("test.csv", header=TRUE)
data=data.frame(dataset)
attach(data)
#population analysis
N=nrow(data)

#--------mean--------#
mean(data$age)
mean(data$education.num)
mean(data$hours.per.week)

#--------standard error--------#
sqrt(var(data$age))
sqrt(var(data$education.num))
sqrt(var(data$hours.per.week))
summary(data)

#--------proportion--------#
data.frame((table(data$sex))/length(data$sex))
data.frame((table(data$education))/length(data$education))
data.frame((table(data$income))/length(data$income))
data.frame((table(data$race))/length(data$race))
data.frame((table(data$native.country))/length(data$native.country))
data.frame((table(data$workclass))/length(data$workclass))



#--------total--------#
table(data$native.country)
table(data$sex)
table(data$race)
table(data$income)

#---------sample 1----------#
set.seed(12345678)
sample(c("Cambodia", "Canada", "China", "Columbia", "Cuba", "Dominican-Republic", "Ecuador", 
         "El-Salvador", "England", "France", "Germany", "Greece", "Guatemala", "Haiti", 
         "Honduras", "Hong", "Hungary", "India", "Iran", "Ireland", "Italy", "Jamaica", 
         "Japan", "Laos", "Mexico", "Nicaragua", "Outlying-US(Guam-USVI-etc)", "Peru", 
         "Philippines", "Poland", "Portugal", "Puerto-Rico", "Scotland", "South", 
         "Taiwan", "Thailand", "Trinadad&Tobago", "United-States", "Vietnam", "Yugoslavia"),8)

target = c("United-States", "Mexico", "Philippines", 
            "Germany", "Canada", "India", "China", "Cuba")
#clustering variable=native country
filt = filter(data, native.country %in% target)
filt
table(filt$native.country)
# sample size
N1 = 14430
a = ((1.96^2)*(0.5*(1-0.5)))/(0.03^2)
n1 = ceiling(a/(1+(a/N1)))
n1

set.seed(12345678)
filt1 = filt[sample(nrow(filt1), n1),]
table(filt1$native.country)

#weight calc
pw1=0
for(i in 1:994){
  if(filt1$native.country[i]=="Canada"){
    pw1=round((56/2)*(40/8),2)
  }else if(filt1$native.country[i]=="China"){
    pw1=round((45/2)*(40/8),2)
  }else if(filt1$native.country[i]=="Cuba"){
    pw1=round((41/3)*(40/8),2)
  }else if(filt1$native.country[i]=="Germany"){
    pw1=round((65/7)*(40/8),2)
  }else if(filt1$native.country[i]=="India"){
    pw1=round((47/3)*(40/8),2)
  }else if(filt1$native.country[i]=="Mexico"){
    pw1=round((293/19)*(40/8),2)
  }else if(filt1$native.country[i]=="Philippines"){
    pw1=round((95/3)*(40/8),2)
  }else if(filt1$native.country[i]=="United-States"){
    pw1=round((13788/955)*(40/8),2)
  }
  pw1 = c(pw1)
}
filt1 = cbind(filt1,pw1)
filt1
write.csv(filt1,"G:\\is3001\\Cluster1.csv", row.names = TRUE)


table(filt1$education)
two_cluster= svydesign(id=~native.country + education, weights=~pw1, data=filt1)

# sample analysis/population estimators
#-------------mean--------------#
svymean(~age, two_cluster)
svymean(~education.num, two_cluster)                   
svymean(~hours.per.week, two_cluster)

#------proportion-------#
svymean(~sex,two_cluster)
svymean(~income,two_cluster)
svymean(~race,two_cluster)
svymean(~education,two_cluster)
svymean(~native.country,two_cluster)
svymean(~workclass,two_cluster)
svymean(~marital.status,two_cluster)
svymean(~occupation,two_cluster)

#-------total--------#
svytotal(~age,two_cluster)
svytotal(~education.num,two_cluster)
svytotal(~hours.per.week,two_cluster)



#---------sample 2---------#
set.seed(23456789)
sample(c("Cambodia", "Canada", "China", "Columbia", "Cuba", "Dominican-Republic", "Ecuador", 
         "El-Salvador", "England", "France", "Germany", "Greece", "Guatemala", "Haiti", 
         "Honduras", "Hong", "Hungary", "India", "Iran", "Ireland", "Italy", "Jamaica", 
         "Japan", "Laos", "Mexico", "Nicaragua", "Outlying-US(Guam-USVI-etc)", "Peru", 
         "Philippines", "Poland", "Portugal", "Puerto-Rico", "Scotland", "South", 
         "Taiwan", "Thailand", "Trinadad&Tobago", "United-States", "Vietnam", "Yugoslavia"),8)

#filter countries

target = c("England", "Mexico", "Philippines", 
            "Germany", "Canada", "Puerto-Rico", "El-Salvador", "Japan")
filter2 = filter(data, native.country %in% target)
filter2
table(filter2$native.country)

#sample size calc
N2 = 685
a = ((1.96^2)*(0.5*(1-0.5)))/(0.03^2)
n2 = ceiling(a/(1+(a/N2)))
n2
set.seed(23456789)
filter2 = filter2[sample(nrow(filter2), n2),]
table(filter2$native.country)

#weight calc
pw2=0
for(i in 1:685){
  if(filt1$native.country[i]=="Canada"){
    pw2=round((56/35)*(40/8),2)
  }else if(filt1$native.country[i]=="El-Salvador"){
    pw21=round((47/30)*(40/8),2)
  }else if(filt1$native.country[i]=="England"){
    pw2=round((33/18)*(40/8),2)
  }else if(filt1$native.country[i]=="Germany"){
    pw2=round((65/44)*(40/8),2)
  }else if(filt1$native.country[i]=="Japan"){
    pw2=round((30/15)*(40/8),2)
  }else if(filt1$native.country[i]=="Mexico"){
    pw2=round((293/181)*(40/8),2)
  }else if(filt1$native.country[i]=="Philippines"){
    pw2=round((95/55)*(40/8),2)
  }else if(filt1$native.country[i]=="Puerto-Rico"){
    pw2=round((66/40)*(40/8),2)
  }
  pw2 = c(pw2)
}
filter2_new = cbind(filter2,pw2)
filter2_new
write.csv(filter2_new,"G:\\is3001\\Cluster2.csv", row.names = TRUE)
table(filter2_new$education)
two_cluster2= svydesign(id=~native.country + education, weights=~pw2, data=filter2_new)
# sample anaylsis/population estimate

#-------------mean--------------#
svymean(~age, two_cluster2)
svymean(~education.num, two_cluster2)                   
svymean(~hours.per.week, two_cluster2)

#------proportion-------#
svymean(~sex,two_cluster2)
svymean(~income,two_cluster2)
svymean(~race,two_cluster2)
svymean(~education,two_cluster2)
svymean(~native.country,two_cluster2)
svymean(~workclass,two_cluster2)
svymean(~marital.status,two_cluster2)
svymean(~occupation,two_cluster2)


#-------total--------#
svytotal(~age,two_cluster2,na.rm=TRUE, deff=TRUE)
svytotal(~education.num,two_cluster2,na.rm=TRUE, deff=TRUE)

#----------graphical analysis------------#

#---histrogram---#
dev.off()
par(mar=c(5, 4, 4, 2) + 0.1)
hist(filt1$age, col="Orange", xlab="Age",
     main="Age Histogram of Sample 1")
hist(filter2_new$age, col="Orange", xlab="Age",
     main="Age Histogram of Sample 2")

#-----barchart------#
ggplot(filt1,aes(x=income))+geom_bar(fill="red")+labs(title="Income barchart of sample 1") 
ggplot(filter2_new,aes(x=income))+geom_bar(fill="red")+labs(title="Income barchart of sample 2") 
#------boxplot-------#
ggplot(filt1, aes(x=sex, y=age))+geom_boxplot(fill="slateblue") + 
 labs(title="age vs sex boxplot of sample 1")
ggplot(filter2_new, aes(x=sex, y=age))+geom_boxplot(fill="slateblue") + 
  labs(title="age vs sex boxplot of sample 2")
#------stack barchart--------#
p=ggplot(filt1, aes(fill=income, x=education)) +geom_bar(position="dodge")
p
p + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+labs(title="educational level with income of sample 1")

q=ggplot(filter2_new, aes(fill=income, x=education)) +geom_bar(position="dodge")
q
q + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+labs(title="educational level with income of sample 2")

#-----scatterplot-----#
plot(filt1$age, filt1$hours.per.week, main="Age,Hours per week Scatterplot of sample 1", xlab="Age", ylab="Hours per week",pch=16)
lines(0:100, 0:100, lwd = 3, col = "red")
plot(filter2_new$age, filter2_new$hours.per.week, main="Age,Hours per week Scatterplot of sample 2", xlab="Age", ylab="Hours per week",pch=16)
lines(0:100, 0:100, lwd = 3, col = "red")


#-------ratio estimates--------#
# sample 1
sep<-svyratio(~age,~hours.per.week, two_cluster,separate=TRUE)
sep
#sample 2
com<-svyratio(~age, ~hours.per.week, two_cluster2)
com
predict(sep, total=15060)
predict(com, total=15060)
