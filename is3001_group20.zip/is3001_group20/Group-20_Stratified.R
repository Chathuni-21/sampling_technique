library(readxl)
library(ggplot2)
install.packages("survey")
install.packages("sampler")
library(sampler)
library(survey)
install.packages("writexl")
library(writexl)

setwd("D:/CAMPUS/THIRD YEAR/1st SEMESTER/IS 3001/Group project")

Dataset=read_xlsx("test.xlsx")
data=data.frame(Dataset)
View(Dataset)

data$workclass <- as.factor(data$workclass)
data$education<- as.factor(data$education)
data$education.num<- as.factor(data$education.num)
data$marital.status<- as.factor(data$marital.status)
data$occupation<- as.factor(data$occupation)
data$race<- as.factor(data$race)
data$sex<- as.factor(data$sex)
data$relationship<- as.factor(data$relationship)
data$native.country<- as.factor(data$native.country)
data$income<- as.factor(data$income)


   #Population mean & SE
mean(data$age)
sqrt(var(data$age))

mean(data$fnlwgt)
sqrt(var(data$fnlwgt))

mean(data$capital.gain)
sqrt(var(data$capital.gain))

mean(data$capital.loss)
sqrt(var(data$capital.loss))

mean(data$hours.per.week)
sqrt(var(data$hours.per.week))


   #Population proportion
table(data$workclass)/15060
table(data$education)/15060
table(data$marital.status)/15060
table(data$occupation)/15060
table(data$relationship)/15060
table(data$race)/15060
table(data$sex)/15060
table(data$native.country)/15060
table(data$income)/15060

sum(data$age)
sum(data$fnlwgt)
sum(data$capital.gain)
sum(data$capital.loss)
sum(data$hours.per.week)


nrow(data)


  #Strata
stratum1=data[data$marital.status=="Married",]
stratum2=data[data$marital.status=="Divorced",]
stratum3=data[data$marital.status=="Never-married",]
stratum4=data[data$marital.status=="Widowed",]

nrow(stratum1)
nrow(stratum2)
nrow(stratum3)
nrow(stratum4)

  #Sample 1
size=rsampcalc(nrow(data),3,95,0.5)
sample1_size=ssampcalc(df=data,n=size,strata = marital.status)
sample1_size

 #obtaining sample 1
set.seed(15060)
strata1=stratsample(data$marital.status,c("Married"=476,"Divorced"=169,"Never-married"=323,"Widowed"=30))
strata_table=data[strata1,]
data2=data.frame(strata_table)
print(data2)
View(strata_table)

nrow(data2)

weight1=round(7183/476,3)
weight2=round(2555/169,3)
weight3=round(4872/323,3)
weight4=round(450/30,3)
data3=data.frame(c("Married","Divorced","Never-married","Widowed"),c(weight1,weight2,weight3,weight4))
colnames(data3)=c("marital.status","WEIGHT")
data3
data4=merge(data2,data3,by="marital.status")
print(data4)
nrow(data4)
design1=svydesign(id=~1,strata = ~marital.status,weights = ~WEIGHT,data = data4)

  #Calculating estimated population means for Sample 1
design1_mean_age=svymean(~age,design = design1) 
design1_mean_age 

design1_mean_fnlwgt=svymean(~fnlwgt,design = design1) 
design1_mean_fnlwgt 

design1_mean_cg=svymean(~capital.gain,design = design1) 
design1_mean_cg 

design1_mean_cl=svymean(~capital.loss,design = design1) 
design1_mean_cl 

design1_mean_hpw=svymean(~hours.per.week,design = design1) 
design1_mean_hpw 



  #Calculating proportions for sample 1 
design1_mean_wc=svymean(~workclass,design = design1) 
design1_mean_wc 
design1_mean_edu=svymean(~education,design = design1) 
design1_mean_edu 
design1_mean_ms=svymean(~marital.status,design = design1) 
design1_mean_ms 
design1_mean_occ=svymean(~occupation,design = design1) 
design1_mean_occ 
design1_mean_rel=svymean(~relationship,design = design1) 
design1_mean_rel 
design1_mean_rc=svymean(~race,design = design1) 
design1_mean_rc 
design1_mean_sex=svymean(~sex,design = design1) 
design1_mean_sex 
design1_mean_nc=svymean(~native.country,design = design1) 
design1_mean_nc 
design1_mean_ic=svymean(~income,design = design1) 
design1_mean_ic 



  #calculating totals for sample 1
design1_total_age=svytotal(~age,design = design1) 
design1_total_age 
design1_total_fnlwgt=svytotal(~fnlwgt,design = design1) 
design1_total_fnlwgt 
design1_total_cg=svytotal(~capital.gain,design = design1) 
design1_total_cg
design1_total_cl=svytotal(~capital.loss,design = design1) 
design1_total_cl
design1_total_hpw=svytotal(~hours.per.week,design = design1) 
design1_total_hpw



 #Calculating estimated population ratios for sample 1 
design1_ratio_1=svyratio(~fnlwgt,~age,design = design1) 
design1_ratio_1 

design1_ratio_2=svyratio(~capital.gain,~age,design = design1) 
design1_ratio_2 

design1_ratio_3=svyratio(~capital.loss,~age,design = design1) 
design1_ratio_3 

design1_ratio_4=svyratio(~hours.per.week,~age,design = design1) 
design1_ratio_4 

  #Graphical analysis for sample 1
boxplot(data4$education.num~data4$income,ylab="Education ",xlab = "Income",main = "Boxplot for Income with Education") 

table1=table(data4$workclass) 
pie(table1,main = "Pie chart for workclass") 

table2=table(data4$race) 
pie(table2,main = "Pie chart for race") 

ggplot(data4,aes(x=workclass))+geom_bar(fill="blue")+labs(title="Distribution of adults' workclass")
ggplot(data4,aes(x=education.num))+geom_bar(fill="red")+labs(title="Distribution of adults' education") 
ggplot(data4,aes(x=race))+geom_bar(fill="green")+labs(title="Distribution of adults' race")           
ggplot(data4,aes(x=marital.status))+geom_bar(fill="yellow")+labs(title="Distribution of adults' marital status")



 #Sample 2
size2=rsampcalc(nrow(data),3,95,0.5)
sample1_size2=ssampcalc(df=data,n=size,strata = marital.status)
sample1_size2

 #obtaining sample 2
set.seed(25060)
strata2=stratsample(data$marital.status,c("Married"=476,"Divorced"=169,"Never-married"=323,"Widowed"=30))
strata_table2=data[strata2,]
data5=data.frame(strata_table2)
#View(data5)

weight5=round(7183/476,3)
weight6=round(2555/169,3)
weight7=round(4872/323,3)
weight8=round(450/30,3)
data7=data.frame(c("Married","Divorced","Never-married","Widowed"),c(weight5,weight6,weight7,weight8))
colnames(data7)=c("marital.status","WEIGHT")
data7
data6=merge(data5,data7,by="marital.status")
#View(data6)

nrow(data6)

design2=svydesign(id=~1,strata = ~marital.status,weights = ~WEIGHT,data = data6)




 #Calculating estimated population means for Sample 2
design2_mean_age=svymean(~age,design = design2) 
design2_mean_age 

design2_mean_fnlwgt=svymean(~fnlwgt,design = design2) 
design2_mean_fnlwgt 

design2_mean_cg=svymean(~capital.gain,design = design2) 
design2_mean_cg 

design2_mean_cl=svymean(~capital.loss,design = design2) 
design2_mean_cl 

design2_mean_hpw=svymean(~hours.per.week,design = design2) 
design2_mean_hpw 



  #Calculating proportions for sample 2
design2_mean_wc=svymean(~workclass,design = design2) 
design2_mean_wc 

design2_mean_edu=svymean(~education,design = design2) 
design2_mean_edu 

design2_mean_ms=svymean(~marital.status,design = design2) 
design2_mean_ms 

design2_mean_occ=svymean(~occupation,design = design2) 
design2_mean_occ 

design2_mean_rel=svymean(~relationship,design = design2) 
design2_mean_rel 

design2_mean_rc=svymean(~race,design = design2) 
design2_mean_rc 

design2_mean_sex=svymean(~sex,design = design2) 
design2_mean_sex 

design2_mean_nc=svymean(~native.country,design = design2) 
design2_mean_nc 

design2_mean_ic=svymean(~income,design = design2) 
design2_mean_ic 

#designmeanhs=data.frame(design1_mean_hs) 

  #calculating totals for sample 2
design2_total_age=svytotal(~age,design = design2) 
design2_total_age 
design2_total_fnlwgt=svytotal(~fnlwgt,design = design2) 
design2_total_fnlwgt 
design2_total_cg=svytotal(~capital.gain,design = design2) 
design2_total_cg
design2_total_cl=svytotal(~capital.loss,design = design2) 
design2_total_cl
design2_total_hpw=svytotal(~hours.per.week,design = design2) 
design2_total_hpw



 #Calculating estimated population ratios for sample 2
design2_ratio_1=svyratio(~fnlwgt,~age,design = design2) 
design2_ratio_1 

design2_ratio_2=svyratio(~capital.gain,~age,design = design2) 
design2_ratio_2 

design2_ratio_3=svyratio(~capital.loss,~age,design = design2) 
design2_ratio_3 

design2_ratio_4=svyratio(~hours.per.week,~age,design = design2) 
design2_ratio_4

 #Graphical analysis for sample 2
boxplot(data6$education.num~data6$income,ylab="Education",xlab = "Income",main = "Boxplot for Income with Education") 

table3=table(data6$workclass) 
pie(table3,main = "Pie chart for workclass") 

table4=table(data6$race) 
pie(table4,main = "Pie chart for race") 

ggplot(data6,aes(x=workclass))+geom_bar(fill="blue")+labs(title="Distribution of adults' workclass")
ggplot(data6,aes(x=education.num))+geom_bar(fill="red")+labs(title="Distribution of adults' education") 
ggplot(data6,aes(x=race))+geom_bar(fill="green")+labs(title="Distribution of adults' race")           
ggplot(data6,aes(x=marital.status))+geom_bar(fill="yellow")+labs(title="Distribution of adults' marital status")



